<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 May 12 Modified in v1.5.7 $
 */

define('HEADING_TITLE', 'Akun Admin');
require DIR_WS_LANGUAGES . $_SESSION['language'] . '/' . 'users.php'; 
