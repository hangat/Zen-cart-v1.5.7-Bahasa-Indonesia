<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: mc12345678 2019 Jun 29 New in v1.5.7 $
 **/
 
 define('TEXT_EMAIL_ADDRESS_VALIDATE', 'Teks yang dimasukkan tidak menyelesaikan ke alamat email yang dapat diterima. (I.e. Nama &lt;email@domain&gt; atau &lt;email@domain&gt; atau email@domain atau kombinasi darinya dipisah oleh koma.)');
 define('TEXT_BOOLEAN_VALIDATE', 'Nilai diperlukan boolean atau equivalen.');