<?php
/**
 * @package admin
 * @copyright Copyright 2003-2012 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Tue Jul 17 22:56:16 2012 -0400 Modified in v1.5.1 $
 */

  define('HEADING_TITLE', 'Laporan Referensi Pelanggan');
  define('TEXT_INFO_SELECT_REFERRAL','Pilih sebuah Kode Kupon/Referensi');
  define('TEXT_REFERRAL_UNKNOWN', 'Tidak Diketahui');
  define('TEXT_INFO_START_DATE', 'Tanggal Mulai (bln-tgl-thn)');
  define('TEXT_INFO_END_DATE', 'Tanggal Akhir (bln-tgl-thn)');
  define('TEXT_ORDER_NUMBER', 'Order #');
  define('TEXT_COUPON_ID', 'ID# Kupon Diskon');
