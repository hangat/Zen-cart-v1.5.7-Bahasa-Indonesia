<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 Apr 18 Modified in v1.5.7 $
 */

define('HEADING_TITLE', 'Peringatan!');
define('ALERT_PART1', 'Peringatan: Anda tidak dapat mengakses admin sampai anda memiliki');
define('ALERT_RENAME_ADMIN', 'rubah folder admin.');
define('ALERT_REMOVE_ZCINSTALL', 'hapus folder zc_install.<br />(Gunakan FTP program anda atau hosting kontrol panel anda.)');
define('ADMIN_RENAME_FAQ_NOTE', 'Bantuan untuk merubah folder admin dapat ditemukan disini');
define('ALERT_PART2', 'Kemudian, untuk mengakses area admin anda, ketik URL admin di browser, misal: <u>http://www.your_site.com/YourAdminFolder/</u> ');
