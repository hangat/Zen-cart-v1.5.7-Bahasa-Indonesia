<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Zcwilt 2020 Apr 27 New in v1.5.7 $
 */

return [
    'id_id' => ['displayName' => 'Indonesia'],
];
