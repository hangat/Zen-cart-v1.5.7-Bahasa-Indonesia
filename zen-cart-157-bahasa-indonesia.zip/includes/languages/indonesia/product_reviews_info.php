<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 10 Modified in v1.5.7 $
 */

define('NAVBAR_TITLE', 'Ulasan');
//define('SUB_TITLE_PRODUCT', 'Product:');
//define('SUB_TITLE_FROM', 'From:');
//define('SUB_TITLE_DATE', 'Date:');
//define('SUB_TITLE_REVIEW', 'Review:');
//define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_OF_5_STARS', '');
