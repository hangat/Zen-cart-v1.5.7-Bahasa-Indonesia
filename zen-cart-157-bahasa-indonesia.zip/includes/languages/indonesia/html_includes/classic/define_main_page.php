<a href="http://www.zen-cart.com/book"><img src="images/large/e-start-book.gif" alt="dapatkan manual anda sekarang" title="Sudahkah anda mendapatkan? Gabung dengan 1000 pengguna Zen Cart yang telah membeli satu-satunya manual pemilik yang komprehensif !" /></a>
<p>Konten ini terdapat dalam berkas: <code> /languages/indonesia/html_includes/classic/define_main_page.php</code></p>
<p>Anda dapat dengan cepat mengedit konten ini melalui Admin->Peralatan->Editor Halaman Penjelasan, dan pilih define_main_page dari kotak tarik turun.</p>
<p><strong>CATATAN: Selalu buat cadangan untuk berkas-berkas dalam<code> /languages/indonesia/html_includes/your_template</code></strong></p>
