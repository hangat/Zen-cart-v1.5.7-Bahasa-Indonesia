<p><strong>Teks Contoh untuk Halaman 3�...</strong></p>
<p>Teks pada bagian ini berasal dari Editor Halaman Penjelasan yang terletak pada menu Peralatan di halaman Admin.</p>
<p>Untuk menghapus teks pada bagian ini, hapuslah dari Editor Halaman Penjelasan.</p>
<p>Berkas ini terletak dalam<code> /languages/indonesia/html_includes/classic/</code></p>
<p><strong>CATATAN: Selalu buat cadangan untuk berkas-berkas dalam<code> /languages/indonesia/html_includes/your_template</code></strong></p>