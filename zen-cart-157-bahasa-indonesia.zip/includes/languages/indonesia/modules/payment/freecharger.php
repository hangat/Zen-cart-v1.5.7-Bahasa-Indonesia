<?php
/**
 * @package payment_modules
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Drbyte Sun Jan 7 21:30:21 2018 -0500 Modified in v1.5.6 $
 */

  define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE', 'Pesanan Gratis');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION', 'Tidak ada biaya untuk pesanan ini. Biasanya digunakan untuk memberikan Pengiriman Gratis. Diperlukan untuk mengizinkan checkout tanpa biaya. Diperlukan untuk unduhan gratis.');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_EMAIL_FOOTER', 'Tidak ada biaya untuk pesanan ini.');
