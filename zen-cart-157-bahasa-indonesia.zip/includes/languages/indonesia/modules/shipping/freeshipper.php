<?php
/**
 * @package shipping_modules
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: freeshipper.php 18697 2011-05-04 14:35:20Z wilt $
 */

define('MODULE_SHIPPING_FREESHIPPER_TEXT_TITLE', 'BEBAS BIAYA KIRIM!');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_DESCRIPTION', 'BEBAS BIAYA KIRIM');
define('MODULE_SHIPPING_FREESHIPPER_TEXT_WAY', 'Tidak Ada Biaya Pengiriman');
